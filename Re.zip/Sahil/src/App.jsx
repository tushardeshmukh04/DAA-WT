import './App.css'
import Header from './Header.jsx'
import Main1 from './Main1.jsx'
import Footer1 from './Footer1.jsx'

function App() {
  

  return (
    <>
    <Header/>
    <Main1></Main1>
    <Footer1></Footer1>
    </>
  )
}

export default App
