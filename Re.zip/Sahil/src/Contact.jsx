
function Contact(){
    return(
        <>
        <h2>This is Contact section</h2>
        </>
    )
}
export default Contact;