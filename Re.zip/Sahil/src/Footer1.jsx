import './footer1.css'
function Footer1() {
    return (
        <>
            <div className='Footer1'>
               <h1>This is Footer of website</h1> 
            </div>
        </>
    )

}
export default Footer1;