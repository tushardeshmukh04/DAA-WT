function Home(){
    return(
        <>
        <h2>This is home section</h2>
        </>
    )
}
export default Home;